function Snake() {
    this.x = 0;
    this.y = 100;
    this.vx = 1;
    this.vy = 0;
    this.total = 0;
    this.calda = [];

    this.comer = function(pos){
      let d = dist(this.x, this.y, pos.x, pos.y);
      if(d<1){
        this.total++;
        return true;
      } else {
        return false;
      }
    }
  
    this.dir = function(dx, dy){
      this.vx = dx;
      this.vy = dy;
      console.log('x: '+ this.vx + ' -- y: ' + this.vy);
    }
  
    this.morrer = function(){
      for(let i = 0; i < this.calda.length; i++){
        let pos = this.calda[i];
        var d = dist(this.x, this.y, pos.x, pos.y);
        if(d<1){
          this.total = 0;
          this.calda = [];
        }
      }
    }
  
    this.update = function(){
      this.morrer();
      if(this.total === this.calda.length){
        for(let i = 0; i< this.calda.length -1; i++){
          this.calda[i] = this.calda[i+1];
        }
      }
      this.calda[this.total-1] = createVector(this.x, this.y);
  
      this.x = this.x + this.vx*scl;
      this.y = this.y + this.vy*scl;
  
      // this.x = constrain(this.x, 0, width-scl);
      // this.y = constrain(this.y, 0, height-scl);
      
      if(this.y <= 0) { this.y = height-scl; }
      if(this.y >= height) { this.y = 0; }
      
      if(this.x <= 0) { this.x = width-scl; }
      if(this.x >= width) { this.x = 0; }
      
      console.log("px: " + this.x);
    }
  
    this.mostrar = function() {
      fill(255);
      for(let i = 0; i<this.total; i++){
        rect(this.calda[i].x, this.calda[i].y, scl, scl);
      }
      rect(this.x, this.y, scl, scl);
    }
  }